#ifndef __SHELLEX_H__
#define __SHELLEX_H__
#include<errno.h>

void eval();//non pipeline command 수행 함수
int parseline(char *buf, char **argv);//cmdline 정제 및 argv에 저장
int builtin_command(char **argv);//builtin command 수행 함수
void do_pipe(char *cmdline,int flag,int input);//pipeline commanad 수행 함수, recursive하게 수행
void token(char* line,char* argv);//cmdline 정제
void push(int pid,char stat,char* cmdline);//job linked list에 push하는 함수
void print_stat(char stat);//job의 status 출력 함수
void amdpointer(char *cmdline);//background process command 정제
void set_system();//프로그램 시작 전 system setting 함수
void dequeue(int jid);//job linked lijst에서 dequeue 하는 함수
void reset_BGPID();//BGPID list reset
void reset_seclet(char c);//seclet 값 node마다 reset
void update_seclet();//seclet 값 node마다 update

typedef struct jobs *job_link;
typedef struct jobs{//job 정보 저장하는 linked list 자료구조
	int jobID;
	int procID;
	char stat;
	char seclet;
	char cmd[MAXLINE];
	job_link next;
}job;


job_link head;
int MAINPID,BG_IDX,BGPID[1000],FG;
char cmdline[MAXLINE],buffer[MAXLINE*100];

#endif
