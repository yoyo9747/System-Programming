/* $begin shellmain */
#include "csapp.h"
#include "myshell.h"
#include<errno.h>
#define MAXARGS   128

void sigint_handler(int sig){//SIGINT를 받을 경우 실행
	if(getpid()!=MAINPID);//child process이면 아무것도 안함
	else{//MAIN process일 경우
		if(FG!=-1){
			kill(FG,SIGKILL);//저장된 foreground의 process id(FG)를 SIGKILL signal을 보내 종료시킨다.
			FG=-1;//종료 시킨 foreground process의 id를 초기화
		}
	}
}
void sigint_prompt(int sig){//SIGINT를 받을 경우 실행(main의 while문 안에서 들어올 경우 실행)
	if(getpid()!=MAINPID);
	else {
		Sio_puts("\nCSE4100-SP-P4> ");
		if(FG!=-1){
			kill(FG,SIGKILL);//저장된 foreground의 process id(FG)를 SIGKILL signal을 보내 종료시킨다.
			FG=-1;//종료 시킨 foreground process의 id를 초기화
		}
	}
}
void sigtstp_handler(int sig){//SIGTSTP를 받을 경우 실행
	if(getpid()!=MAINPID);//child process
	else{
		if(FG!=-1){
			kill(FG,SIGSTOP);//저장된 foreground의 process id(FG)를 SIGSTOP signal을 보내 종료시킨다.
			FG=-1;//종료 시킨 foreground process의 id를 초기화
		}
	}
}
void sigchld_handler(int sig){//SIGChLD를 받을 경우 실행
	int status,i;
	job_link move=head;
	for(i=0;;i++){
		if(BGPID[i]==-1)//background list가 끝날 경우
			break;
		else if(BGPID[i]==0)//background list가 이미 reap 된 경우
			continue;
		if(Waitpid(BGPID[i],&status,WNOHANG)>0){//WNOHANG으로 wait을 한다. (0보다 크면 프로세스가 종료 된 것)
			while(move->next!=NULL){
				move=move->next;
				if(BGPID[i]==move->procID)//해당 종료된 프로세스 찾음
					break;
			}
			if(move->procID!=BGPID[i])//job list에 추가 안되있으면 reset
				BGPID[i]=0;
			else{//올바로 job list에서 찾았으면
				if(buffer[0]==0)//buffer 추가
					sprintf(buffer,"[%d]%c  %-24s%s\n",move->jobID,move->seclet,"Done",move->cmd);
				else
					sprintf(buffer,"%s[%d]%c  %-24s%s\n",buffer,move->jobID,move->seclet,"Done",move->cmd);
				dequeue(move->jobID);	//job list에서 dequeue
				BGPID[i]=0;//reap 완료 체크
			}
		}
	}
}
int main(){
    char temp[MAXLINE]; /* Command line */
    char *argv[MAXARGS]; /* Argument list execve() */
	set_system();
	while (1) {
	/* Read */
		reset_BGPID();//시작할 때마다 BGPID list를 reset 해준다(0인 index  삭제)
		printf("%s",buffer);//Done된 background process 있을 경우 해당 문장 출력
		memset(buffer,0,MAXLINE*100);//buffer reset
		printf("CSE4100-SP-P4> ");
		if(fgets(cmdline, MAXLINE, stdin)==NULL){//command 입력
			printf("11fgets error\n");
			exit(0);
		}
		if (feof(stdin))
			exit(0);
		if(cmdline[0]=='\n')//no command
			continue;
		strcpy(temp,cmdline);//cmdline 정제
		amdpointer(cmdline);//cmdline 정제
		parseline(temp,argv);//cmdline 정제
		/* Evaluate */
		Signal(SIGINT,sigint_handler);//sigint_handler 설치
		if(builtin_command(argv)==0){//built-in command 가 아니면
			if(strchr(cmdline,'|')!=NULL){//pipeline command
					do_pipe(cmdline,0,0);
				}
			else{//non pipeline command
				eval();
			}
		}
		Signal(SIGINT,sigint_prompt);//prompt용 sigint handler 설치
		memset(cmdline,0,MAXLINE);//cmdline reset
	}
}
void eval(){
    char *argv[MAXARGS]; /* Argument list execve() */
    char buf[MAXLINE];   /* Holds modified command line */
    int bg;              /* Should the job run in bg or fg? */
    pid_t pid;           /* Process id */
    strcpy(buf, cmdline);
    bg = parseline(buf, argv);//bg 세팅
    if (argv[0] == NULL)  
		return;   /* Ignore empty lines */
	if((pid = Fork()) ==0){
		Signal(SIGTSTP,SIG_IGN);//child process에선 Ctrl-C무시
		Signal(SIGINT,SIG_IGN);//child procese에선 Ctrl-Z 무시
		FG=-1;//FG reset
		if (execvp(argv[0], argv) < 0) {	//ex) /bin/ls ls -al &
		    printf("%s: Command not found.\n", argv[0]);
		    exit(0);
		}
	}
	/* Parent waits for foreground job to terminate */
	else{
		if (!bg){ //not background
		    int status;
			FG=pid;//foreground setting
			if(Waitpid(pid,&status,WUNTRACED)>0){//wait
				if(WIFSTOPPED(status)){//if SIGSTOPPed
						push(pid,'T',cmdline);//job list에 추가
				}
			}
		}
		else{//background
			BGPID[BG_IDX++]=pid;//background setting
			printf("[%d] %d\n", head->jobID+1, pid);//print info
			push(pid,'R',cmdline);	//job list에 추가
		}
	}
    return;
}
/* $end shellmain */
void do_pipe(char* cmd,int flag,int input){//pipeline command
    char *argv[MAXARGS]; /* Argument list execve() */
	char buf[MAXLINE],arg1[MAXARGS],*arg2;
	int fd[2],pid,bg=0,status;
	if(strchr(cmdline,'&')!=NULL)
		bg=1;//bg 세팅
	flag++;
	strcpy(buf,cmd);
	arg2=strchr(buf,'|');
	if(arg2!=NULL)
		arg2++;//arg2는 pipe 다음 문자열 주소를 가리킨다
	else
		flag=-1;//다음 문자열 주소가 NULL이면 마지막 command
	memset(arg1,0,MAXARGS);
	token(buf,arg1);
	parseline(arg1,argv);//argv에 실행해야할 command 저장
	if(pipe(fd)<0){//file descriptor 
		printf("pipe error");
		exit(0);
	}
	if((pid=Fork())==0){/*child*/
		Signal(SIGTSTP,SIG_IGN);//child process-> Ctrl-C무시
		Signal(SIGINT,SIG_IGN);//child process-> Ctrl-Z무시
		FG=-1;//FG reset
		if(flag==1){//first command
			close(fd[0]);
			dup2(fd[1],STDOUT_FILENO);//out to fd
			if (execvp(argv[0], argv) < 0) {	//ex) /bin/ls ls -al &
			    printf("%s: Command not found.\n", argv[0]);
			    exit(0);
			}
		}
		else if(flag>1){//mid command(from first+1~last-1)
			close(fd[0]);
			dup2(input,STDIN_FILENO);//in from input
			dup2(fd[1],STDOUT_FILENO);//out to fd
			if (execvp(argv[0], argv) < 0) {	//ex) /bin/ls ls -al &
			    printf("%s: Command not found.\n", argv[0]);
			    exit(0);
			}
		}
		else if(flag==-1){//last command
			close(fd[1]);
			dup2(input,STDIN_FILENO);//in from input
			if (execvp(argv[0], argv) < 0) {	//ex) /bin/ls ls -al &
			    printf("%s: Command not found.\n", argv[0]);
			    exit(0);
			}
		}
	}
	else{
		if(flag==-1)
			close(fd[0]);//close fd
		else if(flag!=-1)
			close(fd[1]);//close fd
		if(bg!=1){//foreground
			FG=pid;//FG setting
			if(Waitpid(pid,&status,WUNTRACED)>0){
				if(WIFSTOPPED(status)&&flag==-1){//if SIGSTOPPed
					push(pid,'T',cmdline);//job list에 추가
				}
			}
		}
		else{//background
			BGPID[BG_IDX++]=pid;//BG setting
		}
		if(bg==1&&flag==-1){
			printf("[%d] %d\n", head->jobID+1,pid);//BG 정보 출력(last command)
			push(pid,'R',cmdline);//job list에 추가
		}
		if(flag!=-1)//first or mid command->recursive
			do_pipe(arg2,flag,fd[0]);
	}
}
/* $begin eval */
/* eval - Evaluate a command line */
void dequeue(int jid){//job list에서 jid에 해당하는 job_link dequeue
	job_link move=head,move1;
	char C=0;
	while(move->next!=NULL){
		move1=move;
		move=move->next;
		if(move->jobID==jid){//find
			move1->next=move->next;
			C=move->seclet;
			free(move);//free
			break;
		}
	}
	move=head;
	while(move->next!=NULL){
		move=move->next;
	}
	if(head->next!=NULL)//head->jobID 세팅
		head->jobID=move->jobID;
	else
		head->jobID=0;
	if(C!=0)
		reset_seclet(C);
}
void push(int pid,char stat,char* cmdline){//job list에 추가
	char *pointer;
	job_link new,move;
	new=(job*)malloc(sizeof(job));//new node 정보 입력
	new->jobID=++head->jobID;
	new->procID=pid;
	new->stat=stat;
	new->seclet='+';
	pointer=strchr(cmdline,'&');//command에서 '&' 제거
	if(pointer!=NULL){
		*pointer=0;
		if(*(pointer-1)==' ')
			*(pointer-1)=0;
	}
	pointer=strchr(cmdline,'\n');//command 정제
	if(pointer!=NULL){
		*pointer=0;
		if(*(pointer-1)==' ')
			*(pointer-1)=0;
	}
	strcpy(new->cmd,cmdline);
	new->next=NULL;
	move=head;
	while(move->next!=NULL){//seclet update
		move=move->next;
		if(move->seclet=='+')
			move->seclet='-';
		else if(move->seclet=='-')
			move->seclet=' ';
	}
	move->next=new;
	if(stat=='T')//Stopped 출력(Since Ctrl-Z, bg로 옴)
		printf("[%d]%c  %-24s%s\n",new->jobID,new->seclet,"Stopped",new->cmd);
}
/* If first arg is a builtin command, run it and return true */
void set_system(){
	head=(job*)malloc(sizeof(job));//job_link 헤드 노드 set
	head->jobID=0;
	head->procID=0;
	head->next=NULL;
	MAINPID=getpid();
	memset(BGPID,-1,1000);
	memset(buffer,0,MAXLINE*100);
	Signal(SIGINT,sigint_prompt);//signal handler 설치
	Signal(SIGCHLD,sigchld_handler);
	Signal(SIGTSTP,sigtstp_handler);
	BG_IDX=0;
	FG=-1;
}
void update_seclet(){//fg, bg 단계에서 background update 될 경우 seclet 전체 update
	job_link move=head;
	while(move->next!=NULL){
	move=move->next;
	if(move->seclet=='+')
		move->seclet='-';
	else if(move->seclet=='-')
		move->seclet=' ';
	}
}
int builtin_command(char **argv) //builtin cmd
{
	if(!strcmp(argv[0], "exit")){ /* exit command */
		exit(0);  
	}
    if(!strcmp(argv[0], "&"))    /* Ignore singleton & */
		return 1;
	if(!strcmp(argv[0],"fg")){//fg
		int i,jid=argv[1][1]-'0',pid,status;
		job_link move=head;
		while(move->next!=NULL){
			move=move->next;
			if(move->jobID==jid){//jid에 해당하는 node 찾음
				pid=move->procID;
				printf("%s\n",move->cmd);//cmd 정보 출력
				for(i=0;;i++){
					if(BGPID[i]==-1)
						break;
					else if(BGPID[i]==pid){//BG에서 해당 pid reset
						BGPID[i]=0;
						break;
					}
				}
				FG=pid;//FG 세팅
				kill(pid,SIGCONT);//make continue
				if(Waitpid(pid,&status,WUNTRACED)>0){//foreground wait하듯이 한다
					if(WIFSTOPPED(status)){
						move->stat='T';
						if(move->seclet!='+')//seclet update 필요하다면
							update_seclet();
						move->seclet='+';
						printf("[%d]%c  %-24s%s\n",move->jobID,move->seclet,"Stopped",move->cmd);//Stopped된다면 출력(아직job list에선 dequeue 안 되었기 때문)
					}
					else//stop 안되고 종료 되면 dequeue
						dequeue(jid);
				}
				break;
			}
		}
		return 1;
	}
    if(!strcmp(argv[0],"bg")){//bg
		int jid=argv[1][1]-'0';
		job_link move=head;
		while(move->next!=NULL){//make the state to run
			move=move->next;
			if(move->jobID==jid){//jid에 해당하는 node 찾음
				printf("[%d]+ %s &\n",move->jobID,move->cmd);
				kill(move->procID,SIGCONT);//continue
				move->stat='R';//change status
				if(move->seclet!='+')//seclet 필요 하다면
					update_seclet();
				move->seclet='+';
				break;
			}
		}
		return 1;
	}
	if(!strcmp(argv[0],"kill")){
		int pid,jid,flag=0,status,i;
		char *JID;
		job_link move=head;
		//finding pid...
		if((JID=strchr(cmdline,'%'))!=NULL){
			jid=*(JID+1)-'0';
			while(move->next!=NULL){
				move=move->next;
				if(move->jobID==jid){//jid에 해당하는 node 찾음
					pid=move->procID;
					flag=1;
					break;
				}
			}
		}//pid found
		if(flag==1){//killing pid
			printf("[%d]%c  Killed                  %s\n",move->jobID,move->seclet,move->cmd);
			for(i=0;;i++){
				if(BGPID[i]==-1)
					break;
				else if(BGPID[i]==pid){
					BGPID[i]=0;//BG reset
					break;
				}
			}
			kill(pid,SIGKILL);
			dequeue(jid);
			Waitpid(pid,&status,0);//reap(무조건 끝났을 것이므로 option=0)
		}
		else
			printf("error\n");
		return 1;
	}
	if(!strcmp(argv[0],"jobs")){
		job_link move=head;
		if(head->next==NULL)
			return 1;
		while(move->next!=NULL){//한 node씩 출력
			move=move->next;
			printf("[%d]%c  ",move->jobID,move->seclet);
			print_stat(move->stat);
			printf("%s",move->cmd);
			if(move->stat=='R')
				printf(" &\n");
			else
				printf("\n");
		}
		return 1;
	}
	if(!strcmp(argv[0], "cd")){//cd command(chdir)
		if(chdir(argv[1])<0)
			printf("Change directory error\n");
		return 1;
	}
	return 0;                     /* Not a builtin command */
}
/* $end eval */
void reset_BGPID(){//BGPID list에서 값이 0인 node 제거해줌
	int i=0,j;
	while(1){
		if(BGPID[i]==0){
			j=i;
			while(BGPID[j]!=-1){
				BGPID[j]=BGPID[j+1];
				j++;
			}
			BG_IDX--;
		}
		else if(BGPID[i]==-1)
			break;
		i++;
	}
}
void reset_seclet(char c){//dequeue된 node에 seclet에 따라 update
	int flag;
	job_link move,move1;
	if(c==' ')
		return ;
	else if(c=='-'){
		move=head;
		while(move->next!=NULL){
			move1=move;
			move=move->next;
			if(move->seclet=='+'){
				if(move->jobID==head->jobID){
					if(move1!=head)
						move1->seclet='-';
				}
				else
					flag=1;
			}
		}
		if(flag)
			move1->seclet='-';
	}
	else if(c=='+'){//제거된 seclet='+'일 경우
		move=head;
		while(move->next!=NULL){
			move=move->next;
			if(move->seclet=='-')//'-' seclet을 가지는 node의 seclet이 '+'가 됨
				move->seclet='+';
		}
		move=head;
		while(move->next!=NULL){
			move1=move;
			move=move->next;
			if(move->seclet=='+'){
				if(move1!=head)
					move1->seclet='-';//'-'는 그 전 node의 seclet으로 지정됨
				else
					flag=1;//'+' seclet을 가지는 node가 head 바로 다음 node인 경우
			}
		}
		if(flag){
			move=head;
			while(move->next!=NULL)
				move=move->next;
			if(move->seclet=='+')//node가 하나밖에 없음
				;
			else
				move->seclet='-';
		}
	}
	return ;
}
void print_stat(char stat){//jobs에서 사용, status 출력용
	if(stat=='R')
		printf("%-24s","Running");
	else if(stat=='T')
		printf("%-24s","Stopped");
}
/* $begin parseline */
void amdpointer(char* cmdline){//cmdline 정제용(&를 위함)
	char *pointer=strchr(cmdline,'&');
	if(pointer==NULL)
		return ;
	if(*(pointer-1)!=' '){//command와 &가 붙어있으면
		*(pointer+2)=*(pointer+1);
		*(pointer+1)=*(pointer);
		*(pointer)=' ';
	}
}
void token(char *line,char *arg){//cmdline 정제용
	int i=0;
	while(line[i]!='\0'&&line[i]!='\n'){
		if(line[i]=='|'){
			break;
		}
		arg[i]=line[i];
		i++;
	}
	if(arg[i-1]!=' '){
		arg[i]=' ';
		arg[i+1]='\n';
	}
}
/* parseline - Parse the command line and build the argv array */
int parseline(char *buf, char **argv) {
    char *delim;         /* Points to first space delimiter */
    int argc;            /* Number of args */
    int bg;              /* Background job? */
	buf[strlen(buf)-1] = ' ';  /* Replace trailing '\n' with space */
    while (*buf && (*buf == ' ')) /* Ignore leading spaces */
		buf++;

    /* Build the argv list */
    argc = 0;
    while ((delim = strchr(buf, ' '))) {
		argv[argc++] = buf;
		*delim = '\0';
		buf = delim + 1;
		while (*buf && (*buf == ' ')) /* Ignore spaces */
		        buf++;
    }
    argv[argc] = NULL;
    
    if (argc == 0)  /* Ignore blank line */
	return 1;

    /* Should the job run in the background? */
    if ((bg = (*argv[argc-1] == '&')) != 0)
		argv[--argc] = NULL;
    return bg;
}
/* $end parseline */
