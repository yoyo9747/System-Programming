#include "20171631.h"

int main (){
	char input[input_MAX],input2[input_MAX];
	int move;
	set_system();//프로그램 환경 구성을 위해 set_system()함수를 호출해준다.
	while(1){
		printf("sicsim> " );
		move=0;
		fgets(input,input_MAX,stdin);//명령어 입력
		remove_blank(input);//명령 앞에 공백이 들어갈 경우를 위해 명령어 전에 공백을 없애준다
		input[strlen(input)-1]='\0';//명렁어 입력
		strcpy(input2,input);//명령어 오류 체크를 위해 input2를 만들어준다.
		while((input2[move]!=' '&&input2[move]!='\t')&&input2[move]!=0)//input2에는 공백 전 명령어만 들어간다(index 안들어감)
			move++;
		input2[move]=0;
		if(input==NULL)
			continue;
		else if(!strcmp(input2,"progaddr")){//progaddr 명령 수행			
			sscanf(input,"%*s %X",&csaddr);//progaddr의 값이 어차피 csaddr이 될 것이므로 먼저 csaddr에 입력받는다.
			if(csaddr>0xFFFFF){//에러체크
				printf("wrong progaddr(you dictated progaddr over 1Mbyte\n");
				csaddr=progaddr;
				continue;
			}
			add_history(input);//history에 추가
			progaddr=csaddr;//progaddr값이 세팅된다.
		}
		else if(!strcmp(input2,"loader")){//loader 명령 수행
			free_esymtab();//loader되기 전에 esym_table을 reset 해준다.
			linking_loader(input);//linking_loader 실행
		}
		else if(strcmp(input2,"run")==0){//run 명령 수행
			execute();	//run 실행
			add_history("run");//history에 추가
		}
		else if(!strcmp(input2,"bp")){//bp 명령 수행
			break_point(input);//break_point 실행
			add_history(input);//history 에 추가
		}
		else if(!strcmp(input2,"symbol")){//새로운 assemble file 들어올 때 symboltable 초기화 해줘야함
			if(over_empty_check(input)){
				printf("Input Error, Input h or help to get help\n");
				continue;
			}
			symbol();
			add_history(input2);
		}
		else if(!strcmp(input2,"assemble")){
			assemble(input);
		}
		else if(!strcmp(input2,"type")){
			type_filename(input);
		}
		else if (!strcmp(input2,"h")||!strcmp(input2,"help")){//history 명령어
			if(over_empty_check(input)){
				printf("Input Error, Input h or help to get help\n");
				continue;
			}
			help();
			add_history(input2);
		}
		else if(!strcmp(input2,"d")||!strcmp(input2,"dir")){//directory 명령어
			if(over_empty_check(input)){
				printf("Input Error, Input h or help to get help\n");
				continue;
			}
			dir();
			add_history(input2);
		}
		else if(!strcmp(input2,"hi")||!strcmp(input2,"history")){//history 명령어
			if(over_empty_check(input)){
				printf("Input Error, Input h or help to get help\n");
				continue;
			}
			add_history(input2);
			history();
		}
		else if(!strcmp(input2,"q")||!strcmp(input2,"quit")){//quit 명령어
			if(over_empty_check(input)){
				printf("Input Error, Input h or help to get help\n");
				continue;
			}
			free_data();//동적으로 할당 된 메모리들 free해주고 프로그램 종료
			break;
		}
		else if(!strcmp(input2,"reset")){//reset 명령어
			if(over_empty_check(input)){
				printf("Input Error, Input h or help to get help\n");
				continue;
			}
			reset();
			add_history("reset");
		}
		else if(!strcmp(input2,"du")||!strcmp(input2,"dump")){//dump 명령어
			dump(input);
		}
		else if(!strcmp(input2,"e")||!strcmp(input2,"edit")){//edit 명령어
			edit(input);
		}
		else if(!strcmp(input2,"f")||!strcmp(input2,"fill")){//fill 명령어
			fill(input);
		}
		else if(!strcmp(input2,"opcodelist")){//opcodelist 명령어
			if(over_empty_check(input)){
				printf("Input Error, Input h or help to get help\n");
				continue;
			}
			opcodelist();
			add_history("opcodelist");
		}
		else if(!strcmp(input2,"opcode")){//opcode 명령어
			mnemonic(input);
		}
		else
			printf("Input Error, Input h or help to get help\n");
	}
	return 0;
}
void free_esymtab(){//esym_table 자료구조를 free해주는 함수이다. linking_loader가 실행 될 때 호출된다.
	ex_ptr move1,move2;
	int i;
	csaddr=progaddr;//csaddr reset
	for(i=0;i<3;i++){//row는 3개가 최대이다
		move1=esym_table[i]->next;//첫번째 노드부터 시작
		if(move1==NULL)//첫번째 노드가 null이면 다음 row로 넘어감
			continue;
		move2=move1->next;//free를 while문을 통해 실행해준다.
		while(move2!=NULL){
			free(move1);
			move1=move2;
			move2=move2->next;
		}
		free(move1);
	}
	for(i=0;i<3;i++){//다시 esym_table의 head node들을 reset 해준다.
		esym_table[i]=(ex*)malloc(sizeof(ex));
		esym_table[i]->next=NULL;
		esym_table[i]->address=0;
		esym_table[i]->flag=0;
	}
}
void linking_loader(char* input){//linking_loader의 PASS1을 수행해주는 함수이다.
	char *obj[3],name[7],temp1[7],temp2[7],line[100];
	FILE *f[3];
	int hash,i,j,itemp1,itemp2;
	unsigned int idx;
	ex_ptr move,new;
	strcpy(H_TEMP,input);//오류가 없을 경우 history에 추가해줘야 하므로 복사해준다.
	obj[0]=strtok(input," \t");//각 파일의 이름을 저장해준다.
	obj[0]=strtok(NULL," \t");
	obj[1]=strtok(NULL," \t");
	obj[2]=strtok(NULL," \t");
	if(obj[0]==NULL){//파일이 하나도 입력되지 않은 경우
		printf("Input Error(no object file)\n");
		return;
	}
	objf_cnt=3;//파일의 개수를 나타내는 변수는 3으로 세팅되어있다
	if(obj[2]==NULL) objf_cnt=2;//파일이 2개인 경우 세팅
	if(obj[1]==NULL) objf_cnt=1;//파일이 1개인 경우 세팅
	for(hash=0;hash<objf_cnt;hash++){//파일 개수만큼 반복문을 수행
		f[hash]=fopen(obj[hash],"r");//fopen
		if(f[hash]==NULL){//fopen error
			printf("fopen error\n");
			objf_cnt=hash-1;
			free_esymtab();
			return ;
		};
		move=esym_table[hash];
		while(fgets(line,input_MAX,f[hash])!=NULL){//파일을 한 줄씩 끝까지 읽는다
			if(line[0]=='H'){//H라인인 경우
				for(i=0;i<6;i++){//file name 저장
					if(line[i+1]!=' ')
						name[i]=line[i+1];
					else{
						name[i]='\0';
						break;
					}
				}
				for(i=7;i<7+6;i++)//시작주소 저장
					temp1[i-7]=line[i];
				temp1[6]='\0';
				for(i=13;i<13+6;i++)//프로그램 길이 저장
					temp2[i-13]=line[i];
				temp2[6]='\0';
				itemp1=change_string_to_int(temp1);//값으로 변경
				itemp2=change_string_to_int(temp2);//값으로 변경
				esym_table[hash]->address=itemp2;//CSLTH 저장
				esym_table[hash]->flag++;//해당 index에 있는 symbol 갯수 저장된다
				new=(ex*)malloc(sizeof(ex));//새로운 노드에 값 할당(프로그램명에 대한 external symbol이다)
				new->next=NULL;
				strcpy(new->name,name);
				new->flag=1;
				new->address=itemp1+csaddr;//시작 주소는 itemp1+csaddr일 것!
				move->next=new;
				move=move->next;//다음 저장할 노드 가리킴
			}
			else if(line[0]=='D'){//D라인일 경우
				idx=1;
				while(1){
					if(idx>strlen(line)-2)//idx가 저장해야되는 라인의 길이를 넘어가면 break
						break;
					itemp1=0;//address값
					itemp2=1;//자릿수
					for(j=0;j<6;j++){//external_symbol 이름 저장
						if(line[j+idx]!=' ')
							name[j]=line[j+idx];
						else{
							name[j]='\0';
							break;
						}
					}
					for(j=11;j>=6;j--){//해당 symbol의 값 저장
						if(line[j+idx]>='A'&&line[j+idx]<='F')
							itemp1+=(line[j+idx]-'A')*itemp2;
						else 
							itemp1+=(line[j+idx]-'0')*itemp2;
						itemp2*=16;//자릿수
					}
					new=(ex*)malloc(sizeof(ex));//새로운 노드에 값 할당
					new->next=NULL;
					new->flag=0;
					new->address=itemp1+csaddr;
					strcpy(new->name,name);
					move->next=new;
					move=move->next;
					esym_table[hash]->flag++;//해당 index에 있는 symbol 갯수 저장된다
					idx+=12;//이름 6개 + 주소 6개이므로 12개씩 증가한다
				}	
			}
			else if(line[0]=='E'){
				csaddr+=esym_table[hash]->address;//csaddr은 해당 프로그램의 길이만큼 증가한다
				break;
			}
			else 
				continue;
		}
		fclose(f[hash]);//fclose
	}
	load_map();//external_symbol table이 만들어졌으므로 출력해준다.
	linking_loader2(obj);//linking_loader의 PASS2 수행해하는 linking_loader2 함수 호출
	add_history(H_TEMP);//오류가 없었으므로 history에 추가
}
void linking_loader2(char* obj[3]){//linking_loader의 PASS2를 수행해준다
	FILE *f[3];
	int i,j,hash,idx,len,ref_num[13],ref_idx,form;
	char line[100],tag,name[7],operator,*temp;
	csaddr=progaddr;//처음부터 다시 파일 읽으므로 csaddr은 다시 reset 된다
	execaddr=progaddr;//먼저 execaddr은 progaddr로 초기화 해준다(후에 업데이트 될 것)
	for(hash=0;hash<objf_cnt;hash++){//파일 갯수만큼 반복문 수행
		f[hash]=fopen(obj[hash],"r");//fopen
		while(fgets(line,input_MAX,f[hash])!=NULL){//파일 끝날 때까지 한 줄씩 읽는다
			sscanf(line,"%c\n",&tag);
			if(tag=='H'){//H라인일 경우
				idx=1;
				for(j=1;j<7;j++){
					name[j-1]=line[j];
					if(line[j]==' ')
						name[j-1]=0;
				}
				ref_num[idx]=find_from_esym(name);//1번은 무조건 프로그램명 external_symbol이다
			}
			else if(tag=='R'){//R라인일 경우
				len=strlen(line)-1;
				for(i=1;i<len;i+=8){//index두자리, 해당 external_symbol명이 저장되어있으므로 8씩 증가, line끝까지 증가한다
					idx=change_char_to_int(line[i])*16+change_char_to_int(line[i+1]);//index값 저장
					for(j=i+2;j<i+8;j++){//프로그램 명 저장
						name[j-i-2]=line[j];
						if(line[j]==' '||line[j]=='\n')
							name[j-i-2]=0;
					}
					ref_num[idx]=find_from_esym(name);//찾아서 해당 index에 저장
				}
			}
			else if(tag=='T'){//T라인일 경우
				sscanf(line,"%*c%06X",&idx);//시작 index
				idx+=csaddr;//csaddr을 더해준다
				len=change_char_to_int(line[7])*16+change_char_to_int(line[8]);//저장된 half-byte개수를 값으로 바꾸어준다
				for(i=9;i<9+2*len;i+=2){//알맞게 Memory에 넣어준다
					Memory[idx]=change_char_to_int(line[i])*16+change_char_to_int(line[i+1]);
					idx++;
				}
			}
			else if(tag=='M'){//M라인일 경우
				sscanf(line,"%*c%06X%02X%c%02X",&idx,&form,&operator,&ref_idx);
				modify(idx+csaddr,form,operator,ref_num[ref_idx]);//ref_idx에 맞게 Memory의 값을 바꿔주는 modify함수를 호출해준다
			}
			else if(tag=='E'){
				if(strcmp(Delete_Space(line),"E")!=0){//E만 있는 경우가 아닐 경우 이 line에 execaddr의 값이 들어간다. 해당 값을 저장해준다.
					temp=Delete_Space(line);
					temp=strtok(temp,"E");
					execaddr=csaddr+change_string_to_int(temp);
				}
				csaddr+=esym_table[hash]->address;//csaddr 업데이트(operand에 길이 저장되어있음)
			}
		}
		fclose(f[hash]);//fclose
	}
	set_register();//loading까지 완료 되었으므로 run을 위해 register을 reset 해준다.
}
int find_from_esym(char* name){//esym_table에서 name에 해당하는 symbol을 찾아서 값을 return 해주는 함수이다.
	int i;
	ex_ptr move;
	for(i=0;i<objf_cnt;i++){//파일 갯수만큼 반복문
		move=esym_table[i]->next;
		while(move!=NULL){
			if(strcmp(name,move->name)==0)//같으면 address return
				return move->address;
			move=move->next;//안 같으면 다음 node
		}
	}
	return 0;
}
void modify(int idx,int form,char operator,int operand){//Memory[idx]로부터 operator에 맞게 operand를 연산해준다.
	int target=0;
	//우선 target값을 현재 Memory값으로 세팅해준다. 그 후 해당 half-byte 자리의 Memory 값은 0으로 바꾸어준다
	if(form==5){//5 half-byte
		target+=(Memory[idx]%16)*256*256;
		Memory[idx]-=Memory[idx]%16;
	}
	else{//6 half-byte 
		target+=Memory[idx]*256*256;
		Memory[idx]=0;
	}
	target+=Memory[idx+1]*256+Memory[idx+2];
	Memory[idx+1]=0;
	Memory[idx+2]=0;
	if(operator=='+')//operator에 맞게 연산을 수행한다
		target+=operand;
	else if(operator=='-'){
		if(target-operand<0)
			target=0x1000000-(operand-target);
		else target-=operand;
	}
	if(form==5){//다시 Memory에 값을 넣어준다
		Memory[idx]+=(target/(256*256))%16;
	}
	else{
		Memory[idx]+=(target/(256*256))%256;
	}
	Memory[idx+1]+=(target/256)%256;
	Memory[idx+2]+=target%256;
}
void load_map(){//esym_table을 출력해주는 함수이다.
	int hash,i;
	ex_ptr move;
	printf("control symbol address length\n");
	printf("section name\n");
	printf("--------------------------------\n");
	for(hash=0;hash<objf_cnt;hash++){//파일 개수만큼 출력
		move=esym_table[hash]->next;//move를 옮겨가면서 출력한다 
		for(i=0;i<esym_table[hash]->flag;i++){
			if(move->flag==1){//flag==1이라면 프로그램 명이 저장된 symbol이라는 뜻
				printf("%-6s             %04X   %04X\n",move->name,move->address,esym_table[hash]->address);
			}
			else if(move->flag==0){
				printf("          %6s   %04X\n",move->name,move->address);
				
			}
			move=move->next;
		}
	}
	printf("--------------------------------\n");
	printf("             total length %04X\n",csaddr-progaddr);//시작 길이부터 끝 길이까지 저장한다(csaddr은 loader가 끝나서 프로그램 끝의 index로 바뀌어있다
}
void set_register(){//register값들을 reset해주는 함수이다. 거의 다 0으로 셋 되지만 reg[2]는 프로그램 끝 index, reg[8]은 첫 instruction의 index로 reset 된다
	reg[0]=0;//A
	reg[1]=0;//X
	reg[2]=csaddr;//L
	reg[3]=0;//B
	reg[4]=0;//S
	reg[5]=0;//T
	reg[6]=0;//F
	reg[8]=execaddr;//PC
	reg[9]=0;//SW
}
void execute(){//run을 수행해주는 함수이다.
	int S=reg[8],E=csaddr;
	bp_ptr move=head_bp;
	while(S<E){
		interpret_objcode(S);//S index부터 시작해서 instruction을 해석해서 reg와 memory를 업데이트 해주는 interpret_objcode함수를 호출한다
		S=reg[8];//S값도 pc값에 맞게 업데이트 해준다.
		for(move=head_bp->next;move!=NULL;move=move->next){//break_point에 해당하는지 검사한다.
			if(S==move->point){//break_point라면 현재 register값들을 출력하고 함수 종료
				printf("A : %06X  X : %06X\n",reg[0],reg[1]);
				printf("L : %06X PC : %06X\n",reg[2],reg[8]);
				printf("B : %06X  S : %06X\n",reg[3],reg[4]);
				printf("T : %06X\n",reg[5]);
				printf("          Stop at checkpoint[%X]\n",S);
				return ;
			}
		}
	}
	//while문 끝났다면 프로그램 종료, 종료시의 register값들을 출력하고 함수를 종료한다.
	printf("A : %06X  X : %06X\n",reg[0],reg[1]);
	printf("L : %06X PC : %06X\n",reg[2],reg[8]);
	printf("B : %06X  S : %06X\n",reg[3],reg[4]);
	printf("T : %06X\n",reg[5]);
	printf("          End Program\n");
	set_register();//프로그램이 끝났으므로 다시 register을 reset 해준다.
}
void interpret_objcode(int S){//S index부터해서 instruction을 분석해서 명령을 수행하는 함수이다.
	int n,i;
	i=Memory[S]%2;//i는 Memory[S]의 8번째 bit
	n=(Memory[S]%4-i)/2;//n은 Memory[S]의 7번째 bit
	if(n==0&&i==0)//format 1,2일 것이다
		run_format12(S);
	else//format 3, 4
		run_format34(S,n,i);
}
void run_format12(int idx){//format 1,2의 instruction을 수행해주는 함수이다. 각 opcode에 맞게 명령을 수행한다.
	int R1,R2;
	if(Memory[idx]==0xB4){//CLEAR
		R1=Memory[idx+1]/16;//register index입력받음
		reg[R1]=0;//reset
	}
	else if(Memory[idx]==0xB8){//TIXR
		R1=Memory[idx+1]/16;
		reg[1]++;
		if(reg[1]<reg[R1])
			reg[9]='<';
		else if(reg[1]==reg[R1])
			reg[9]='=';
		else 
			reg[9]='>';
	}
	else if(Memory[idx]==0xA0){//COMPR
		R1=Memory[idx+1]/16;
		R2=Memory[idx+1]%16;
		if(reg[R1]<reg[R2])
			reg[9]='<';
		else if(reg[R1]==reg[R2])
			reg[9]='=';
		else 
			reg[9]='>';
	}
	else if(Memory[idx]==0xC4||Memory[idx]==0xC0){
		reg[8]+=1;
		return ;
	}
	else if(Memory[idx]==0xF4||Memory[idx]==0xC8){
		reg[8]+=1;
		return ;
	}
	else if(Memory[idx]==0xF0||Memory[idx]==0xF8){
		reg[8]+=1;
		return ;
	}//format 1이면 pc값 1만 증가한다
	reg[8]+=2;//format 2이면 pc값 2만 증가한다
}
void run_format34(int idx,int n,int i){//format 3,4 인 경우
	int target,x,b,p,e,address=0,disp=0;
	target=Memory[idx+1]/16;
	x=target/8;//x 세팅
	target-=x*8;
	b=target/4;//b 세팅
	target-=b*4;
	p=target/2;//p 세팅
	e=target%2;//e 세팅
	if(e==0){//format 3
		disp=(Memory[idx+1]%16)*256+Memory[idx+2];
		reg[8]+=3;//pc+=3
	}
	else {//format 4
		disp=(Memory[idx+1]%16)*256*256+Memory[idx+2]*256+Memory[idx+3];
		reg[8]+=4;//pc+=4
	}
	if(b==0&&p==0){//direct addressing
		address=disp;
	}
	else if(b==1&&p==0){//base relative addressing
		address=reg[3]+disp;
	}
	else if(b==0&&p==1){//pc relative addressing
		if(disp>2047){
			disp=0x1000-disp;
			address=reg[8]-disp;
		}
		else 
			address=reg[8]+disp;
	}
	if(x==1)//index addressing
		address+=reg[1];
	run_opcode(Memory[idx]-n*2-i,n,i,address);//opcode에 맞게 명령을 수행해주는 run_opcode함수를 호출해준다
}
void run_opcode(int opcode,int n,int i,int address){//opcode에 맞게 명령을 수행해주는 run_opcode 함수이다. 각 opcode와 n, i bit에 맞게 store_word, load_word, comp, get_address함수를 호출해주고, register과 memory의 값을 update해준다
	if(opcode==0x0C){//STA
		store_word(reg[0],n,i,address);
	}	
	else if(opcode==0x14){//STL
		store_word(reg[2],n,i,address);
	}
	else if(opcode==0x10){//STX
		store_word(reg[1],n,i,address);
	}
	else if(opcode==0x54){//STCH
		Memory[address]=reg[0]%256;
	}
	else if(opcode==0x0){//LDA
		load_word(0,n,i,address);
	}
	else if(opcode==0x68){//LDB
		load_word(3,n,i,address);
	}
	else if(opcode==0x74){//LDT
		load_word(5,n,i,address);
	}
	else if(opcode==0x50){//LDCH
		reg[0]-=reg[0]%256;
		reg[0]+=Memory[address];
	}
	else if(opcode==0x48){//JSUB	
		reg[2]=reg[8];
		reg[8]=address;
	}
	else if(opcode==0x28){//COMP
		comp(n,i,address);
	}
	else if(opcode==0x3C){//J
		if(n==1&&i==0)
			address=get_address(address);
		reg[8]=address;
	}
	else if(opcode==0x38){//JLT
		if(reg[9]=='<')
			reg[8]=address;
	}
	else if(opcode==0x38){//JGT
		if(reg[9]=='>')
			reg[8]=address;
	}
	else if(opcode==0x30){//JEQ
		if(reg[9]=='=')
			reg[8]=address;
	}
	else if(opcode==0xE0){//TD
		reg[9]='<';
	}
	else if(opcode==0xD8){//RD
		reg[0]=0;
	}
	else if(opcode==0xDC){//WD
		;
	}
	else if(opcode==0x4C){//RSUB
		reg[8]=reg[2];
	}
}
int get_address(int idx){//해당 index로부터 3 byte만큼의 값을 return 해준다(6자리 16진수)
	int address;
	address=Memory[idx]*256*256+Memory[idx+1]*256+Memory[idx+2];	
	return address;
}
void store_word(int value,int n,int i,int idx){//word(value)를 메모리에 저장하는 함수이다.
	int digit1=value/(256*256),digit2=value,digit3;
	value-=digit1*256*256;
	digit2=value/256;
	value-=digit2*256;
	digit3=value;
	if(n==1&&i==0)
		idx=get_address(idx);
	Memory[idx]=digit1;
	Memory[idx+1]=digit2;
	Memory[idx+2]=digit3;
}
void load_word(int ridx,int n,int i,int idx){//rdix에 해당하는 register에 idx에 해당하는 3byte  address를 입력해준다.
	if(n==0&&i==1)
		reg[ridx]=idx;
	else if(n==1&&i==1)
		reg[ridx]=get_address(idx);
	else if(n==1&&i==0){
		idx=get_address(idx);
		reg[ridx]=get_address(idx);	
	}
}
void comp(int n,int i,int idx){//idx에 해당하는 memory의 address와 A register을 비교한 후 결과를 SW register에 업데이트 해준다
	if(n==1&&i==1)
		idx=get_address(idx);
	else if(n==1&&i==0){//indirect addressing
		idx=get_address(idx);
		idx=get_address(idx);
	}
	if(idx<reg[0])
		reg[9]='<';
	else if(idx==reg[0])
		reg[9]='=';
	else
		reg[9]='>';
}
void break_point(char* input){//bp 명령을 수행해주는 함수이다.
	int cmp;
	char *temp,temp2[20];
	bp_ptr free1,move;
	strcpy(temp2,Delete_Space(input));
	if(strcmp(temp2,"bp")==0){//bp만 들어갔을 경우 break_point들 다 출력
		printf("                   breakpoint\n");
		printf("                   ----------\n");
		if(head_bp->point==0) return ;//break_point이 없을 경우 출력 안 하고 종료
		move=head_bp->next;
		while(move!=NULL){
			printf("                   %X\n",move->point);
			move=move->next;
		}
		return ;
	}
	temp=strtok(temp2,"p");	
	temp=strtok(NULL,"\0");
	if(strcmp(temp,"clear")==0){//clear이 들어올 경우 모든 break_point를 삭제해준다
		head_bp->point=0;
		move=head_bp->next;
		while(move!=NULL){
			free1=move;
			move=move->next;
			free(free1);
		}
		head_bp->next=NULL;
		printf("[ok] clear all breakpoints\n");
	}
	else{//break_point를 추가해준다
		move=head_bp;
		cmp=progaddr+change_string_to_int(temp);
		while(move->next!=NULL){
			move=move->next;
			if(move->point==cmp){//이미 해당 break_point가 있을 경우 추가하지 않는다
				printf("there already is %X\n",move->point);
				return ;
			}
		}//while문이 끝난다면 move에는 마지막 node가 저장된다
		free1=(bp*)malloc(sizeof(bp));
		free1->point=cmp;
		free1->next=NULL;
		move->next=free1;
		printf("[ok] create breakpoint %X\n",cmp);
		head_bp->point++;
	}
}
void assemble(char* input){
	char* f_name;
	if((f_name=check_filename(input,1))==NULL)//오류메세지 check_filename  함수 내에서 출력,  오류일 경우 종료
		return ;
	strcpy(H_TEMP,"assemble ");
	strcat(H_TEMP,f_name);//add_history 수앵하기 위해 H_TEMP 세팅
	if(PASS1(f_name)){//PASS1 함수 실행 각종 오류를 잡으며 오류 있으면 1 return되서 프로그램 종료됨
		free_symbol(2);	
		return ;
	}
	free_symbol(1);//만약 한 프로그램 내에 assemble이 두번 실행 되는 거라면 symbol table이 free돼야 한다
	copy_symbol();//reset 된 symbol table에 temp_symbol table 복사
	free_symbol(2);//복사했으므로 temp_symbol table free
	//프로그램 종료될 때 symbol table은 quit 명령일 때 호출하는 free_data함수 에서 free되도록 구현하였다.
	PASS2(f_name);//PASS2함수 실행
	remove(f_name);//intermediate file 삭제
	add_history(H_TEMP);//history 자료구조에 assemble 명령을 추가한다
}
char* check_filename(char* input,int mode){//제대로 된 파일인지 검사하는 함수이다. mode==1이 될 경우 asm파일인지 까지 검사한다
	char* f_name,f_check[5];
	int i;
	f_name=strtok(input," \t");
	f_name=strtok(NULL,"\0");
	if(over_empty_check(f_name)){//파일 이름에 공백 섞여있는지 검사
		printf("Input Error, Input h or help to get help\n");
		return NULL;	
	}
	f_name=Delete_Space(f_name);
	if(f_name==NULL){//파일 이름이 공백으로만 이루어져 있는지 검사
		printf("Input Error, Input h or help to get help\n");
		return NULL;
	}
	if(mode==1){//asm 파일인지 검사
		for(i=0;i<5;i++)
			f_check[4-i]=f_name[strlen(f_name)-i];
		if(strcmp(f_check,".asm")){
			printf("File format error(must be asm file)\n");
			return NULL;
		}	
	}
	return f_name;
}
void type_filename(char* input){//type 명령을 수행하는 함수이다
	FILE* f;
	char* f_name;
	char C;
	if((f_name=check_filename(input,0))==NULL)//제대로 된 파일인지 검사
		return ;
	if((f=fopen(f_name,"r"))==NULL){//존재 하지 않는 파일일 경우
		printf("There is no file that name is %s\n",f_name);
		return ;
	}
	while(1){//파일 내용 그대로 출력
		if(fscanf(f,"%c",&C)!=EOF){
			printf("%c",C);
		}
		else
			break;
	}
	fclose(f);
	strcpy(H_TEMP,"type ");
	strcat(H_TEMP,f_name);
	add_history(H_TEMP);//history 자료구조에 temp 명령을 추가한다
}
int PASS1(char* f_name){//PASS1 알고리즘, temp_symbol table 만들어주며, intermediate file을 만들어준다 또 오류 검사 한다 오류면 1 return, 오류 아니면 0 return
	FILE *f,*itm_f;
	char line[100],*label,*opcode,*operand,*regi;
	unsigned int locctr=0;
	int mpo,linectr=0,ex_flag,mode_flag,type_flag,idx_flag;
	program_length=0;
	base=0;
	if((f=fopen(f_name,"r"))==NULL){//파일 존재하지 않으면 오류
		printf("There is no file that name is %s\n",f_name);
		return 1;
	}
	f_name=strtok(f_name,".");//intermediate file 명은 asm파일에서 .asm을 뺀 이름이 된다.
	itm_f=fopen(f_name,"w");//intermediate file open
	while((fgets(line,input_MAX,f))!=NULL){//한줄 씩 asm파일 끝날때까지 읽는다
		line[strlen(line)-1]=0;
		linectr+=5;//line number은 5씩 증가
		idx_flag=0;//x bit set
		if(line[0]=='.'){//주석일 경우
			fprintf(itm_f,"%d %s\n",linectr,line);
			continue;
		}
		//한줄의 입력은 기본적으로 ,를 사용할 경우와(operand 두개)  안 사용할 경우로 나뉜다(operand 한개)
		if(strchr(line,',')!=NULL){//operand 2개
			label=Delete_Space(strtok(line," \t"));
			opcode=Delete_Space(strtok(NULL,", \t"));
			operand=Delete_Space(strtok(NULL,","));
			regi=Delete_Space(strtok(NULL,"\0"));
			if(line[0]==' '||line[0]=='\t'){//label 없을 경우
				strcat(opcode,",");
				strcat(opcode,operand);
				operand=opcode;
				opcode=label;
				label=NULL;
			}
			else{//label 있을 경우
				strcat(operand,",");
				strcat(operand,regi);
			}//여기까지 하면 label, opcode, operand에 각 해당 값들이 저장된다(operand에는 operand 2개가 ,로 구분되서 들어감(ex: BUFFER,X)
			if(operand[strlen(operand)-1]=='X')
				idx_flag=1;//index 연산일 경우 idx_flag=1로 세팅
		}
		else{//operand 1개일 경우
			label=Delete_Space(strtok(line," \t"));
			opcode=Delete_Space(strtok(NULL," \t"));
			operand=Delete_Space(strtok(NULL,"\0"));
			if(operand==NULL&&(line[0]==' '||line[0]=='\t')){
				if(opcode!=NULL)
					operand=opcode;
				opcode=label;
				label=NULL;
			}
		}//여기까지 하면 label, opcode, operand에 각 해당 값들이 저장된다
		//각 문자열들 분석 시작
		if(!strcmp(opcode,"END")){//opcode==END면 다 읽었다.
			break;
		}
		if(!strcmp(opcode,"START")){//opcode==START이면 operand를 start_address에 저장해주고, 첫 locctr을 세팅해준다
			start_address=change_string_to_int(operand);
			locctr=start_address;
			strcpy(program_name,label);//label엔 program_name이 저장되어있다
			continue;
		}
		ex_flag=0;//e bit set
		mode_flag=0;//n, i bit set
		type_flag=0;//operand type을 나타내주는 flag이다
		mpo=0;//memory per opcode
		ex_flag=analyze_opcode(opcode);//analyze_opcode함수는 opcode앞에 +가 있으면 1을 return해주고, opcode 문자열에서 +를 떼준다
		if(operand!=NULL)
			mode_flag=analyze_mode(operand);//#이 붙어있으면 1, @이 붙어있으면 2,안 붙어있으면 0을 return하고 #, @을 operand 문자열에서 빼준다
		///////제대로 된 라인//////
		if(label!=NULL){//label이 있을 경우 symbol table에 있는지, opcode table에 있는지, 예약된 directive와 같은지  검사하고 있으면 오류 오류가 아니라면 add_symbol함수가 정상적으로 수행된다
			if(add_symbol(label,locctr)){
				printf("symbol error in line number %d\n",linectr);
				return 1;
			}
		}
		if(search_opcode(opcode,1)!=-1){//opcode가 opcodelist에 있다면 해당 format을 mpo에 입력(4 형식은 나중에 반영해준다)
			mpo=search_opcode(opcode,1);
		}
		else if(!strcmp(opcode,"BASE"))		//BASE면 아직 BASE directive값 모르므로 그냥 넘겨준다
			;
		else if(!strcmp(opcode,"WORD")){//WORD변수 하나는 3byte니까 mpo=3
			mpo=3;
		}
		else if(!strcmp(opcode,"RESW")){//analyze_value1,2 함수를 통해 type_flag에 따라 각 해당하는 값들이 return 되고 그것만큼의 word개수인 거니까 3을 곱해 mpo에 입력
			type_flag=analyze_value1(operand);
			mpo=3*analyze_value2(type_flag,operand);
		}
		else if(!strcmp(opcode,"RESB")){//RESW와 같지만 BYTE니까 *3은 하지 않는다
			type_flag=analyze_value1(operand);
			mpo=analyze_value2(type_flag,operand);
		}
		else if(!strcmp(opcode,"BYTE")){//BYTE에 해당되는 만큼 mpo를 넣어준다(X'05', C'EOF'의 경우 고려해주었다.
			type_flag=analyze_value1(operand);
			if(analyze_value2(type_flag,operand)==-1){//잘못된 hexa값 들어갈 경우를 오류체크해준다.
				printf("error in line number %d\n",linectr);
				return 1;	
			}
			if(type_flag==1)
				mpo=(strlen(operand)-3+1)/2;//n.5byte들어올 경우를 고려해주었다(무조건 단위가 byte로 올림되도록)
			else if(type_flag==2)
				mpo=strlen(operand)-3;
		}
		else{//opcode table에도 없고 정의되있는 directive도 아니면 오류
			printf("opcode error\n");
			return 1;
		}
		fprintf(itm_f,"%d %s %d %s %d %s %d %d %04X %04X\n",linectr,label,ex_flag,opcode,mode_flag,operand,type_flag,idx_flag,locctr,locctr+mpo+ex_flag);//line에서 추출된 정보들 정제된 형태로 intermediate file에 출력해준다
		locctr+=(mpo+ex_flag);//해당 line에 결과로 나온 mpo를 locctr에 더해준다(format 4이면 1을 더 더한다)
	}
	program_length=locctr-start_address;
	printf("%X\n",program_length);
	fclose(f);
	fclose(itm_f);
	return 0;
}
void PASS2(char *f_name){//여기서부턴 오류 생기면 안됨
	FILE *f,*lst;
	char *temp,temp2[30],first[30],line[120],label[30],opcode[30],operand[30],f_lst[30];
	unsigned int locctr,obj_code;
	int linectr,ex_flag,ni,type_flag,idx_flag,SV,OV,xbpe,pc;
	strcpy(f_lst,f_name);
	strcat(f_lst,".lst");
	printf("[%s], [%s.obj]\n",f_lst,f_name);
	f=fopen(f_name,"r");
	lst=fopen(f_lst,"w");//lst 파일 오픈
	fprintf(lst,"5         %04X    %-7sSTART  %X\n",start_address,program_name,start_address);//첫줄 입력(첫줄과 끝줄은 굳이 intermediate file에 입력시키지 않았다)
	while((fgets(line,input_MAX,f))!=NULL){
		line[strlen(line)-1]=0;
		sscanf(line,"%d %s %d %s %d %s %d %d %X %X",&linectr,label,&ex_flag,opcode,&ni,operand,&type_flag,&idx_flag,&locctr,&pc);//정제된 data들을 알맞게 입력받는다
		SV=0;//symbol의 value를 저장
		OV=0;//opcode의 value를 저장
		obj_code=0;//obj_code 값 저장
		xbpe=0;//xbpe bit이 들어가는 3번째 byte값 저장
		if(label[0]=='.'){//주석일 때 형식 맞춰서 출력해준다
			temp=strtok(line,".");
			temp=strtok(NULL,"\0");//주석 내용 저장
			fprintf(lst,"%-18d.",linectr);
			if(temp!=NULL){
				fprintf(lst,"%s\n",temp);
			}
			else
				fprintf(lst,"\n");
			continue;
		}
		if(strcmp(opcode,"BASE")==0){//BASE directive 선언 될 때 BASE값 저장+ BASE line에 들어갈 내용 형식 맞춰서 출력
			fprintf(lst,"%-10d               BASE   %s\n",linectr,operand);
			base=search_symbol(operand);
			continue;
		}
		fprintf(lst,"%-10d%04X    ",linectr,locctr);//index 부분 출력
		if(strcmp(label,"(null)")!=0){//label 존재 할 경우
			fprintf(lst,"%-7s",label);
			if(search_symbol(label)==start_address)//END line에 출력될 START directive의 label이 나오면 first에 저장한다
				strcpy(first,label);
		}
		else
			fprintf(lst,"       ");//label 없으면 형식 맞춰서 공백 출력
		if(ex_flag)	//format 4인 경우
			fprintf(lst,"+");
		fprintf(lst,"%-6s",opcode);//opcode는 무조건 있으니까 조건 없이 출력
		if(ex_flag==0)//format 4아니면 lst파일 형식 맞추기 위해 공백 하나 더 출력(format 4일 때 +를 출력해줌)
			fprintf(lst," ");
		if(ni==1)//ni값에 따라 #(immediate), @(indirect)연산 기호 출력
			fprintf(lst,"#");
		else if(ni==2)
			fprintf(lst,"@");
		if(strcmp(operand,"(null)")!=0){//operand가 있다면
			if(strchr(operand,',')!=NULL){//operand 2개인경우 ,와 두번째 operand사이에 공백 하나더 넣어준다
				temp=strtok(operand,",");
				temp=strtok(NULL,"\0");
				strcpy(temp2,temp);
				strcat(operand,", ");
				strcat(operand,temp2);
			}
			fprintf(lst,"%-14s",operand);//operand 조건 맞춰서 출력
		}
		else
			fprintf(lst,"              ");//operand 없으면 형식 맞춰서 공백 출력
		if(ni==0){//아까 ni값에 따라 #, @ 출력하지 않았을 경우엔 기호 대신 공백을 하나 더 출력해준다
			fprintf(lst," ");
			ni=3;//SIC/XE에선 ni=0이 되는 경우는 없으므로 immediate도 indirect도 아니면 ni=3으로 세팅
		}
		//////////////////////////////////////////////////////////obj code  writing
		OV=search_opcode(opcode,2);//OV=opcode값들어감
		if(OV!=-1){//opcode table 에 opcode가 존재할 경우
			if(search_opcode(opcode,1)==1){//format 1
				obj_code=OV;
				fprintf(lst,"%02X\n",obj_code);
				continue;
			}
			if(search_opcode(opcode,1)==2){//format 2
				obj_code+=OV*256;
				obj_code+=format2(operand);//format2함수로 register값에 따라 obj_code를 설정해준다
				fprintf(lst,"%04X\n",obj_code);
				continue;
			}
			strtok(operand,",");
			xbpe+=(8*idx_flag+ex_flag);//x, e bit 세팅
			SV=search_symbol(operand);//SV = symbol 값 들어감
			if(SV!=-1&&ex_flag!=1){//xbpe ,SV set한다
				if(SV-pc<=2047&&SV-pc>=-2048){//pc relative addressing 가능할 경우
					xbpe+=2;//p 세팅
					if(SV<pc)
						SV=4096-(pc-SV);//SV-pc가 음수일 경우, 마지막 3bit만 필요하므로 해당 값만 입력시켜준다
					else
						SV-=pc;
				}
				else{//base relative addressing 가능할 경우
					xbpe+=4;//b 세팅
					SV=SV-base;
				}
			}
			obj_code+=(OV+ni)*256*256+xbpe*256*16;//OV+vi 같은 첫 2byte, xbpe 3번째 byte
			obj_code*=(256-255*(1-ex_flag));//e=1인 경우 자리수 2byte씩 증가(256 곱해줌)
			//이제 operand에 대한 값들 더해주면 된다
			if(ni==1){//immediate mode
				if(SV!=-1)//symbol table에 symbol있는 경우, pc, base addressing 계산 되있음
					obj_code+=SV;
				else
					obj_code+=analyze_value2(analyze_value1(operand),operand);//값으로 직접 들어온 경우, operand 분석해서 해당 값 넣어준다
			}
			else{//immediate 아니면 그냥 last 3 byte 채워주면 된다(계산은 다 돼있음)
				if(SV!=-1)
					obj_code+=SV;
			}
			if(ex_flag){//extend mode면 8자리 출력
				fprintf(lst,"%08X\n",obj_code);
				continue;
			}
			else{//extend mode아닌 format3 이면 6자리 출력
				fprintf(lst,"%06X\n",obj_code);
				continue;
			}
		}
		else if(strcmp(opcode,"RESW")==0){//RESW, RESB일 경우엔 obj_code 출력 안 해줘도 된다
			fprintf(lst,"\n");
			continue;
		}
		else if(strcmp(opcode,"RESB")==0){
			fprintf(lst,"\n");
			continue;
		}
		else if(strcmp(opcode,"WORD")==0){//WORD directive인 경우 해당 operand 분석해서 6자리로 출력해준다
			obj_code=analyze_value2(analyze_value1(operand),operand);
			fprintf(lst,"%06X\n",obj_code);//WORD 배정이니까 무조건 3byte이다
			continue;
		}
		else if(strcmp(opcode,"BYTE")==0){//BYTE directive인 경우 해당 operand 분석해서 BYTE단위로 들어온 만큼 출력해준다
			if(type_flag!=1){//hexa mode 아닐 경우
				obj_code=analyze_value2(analyze_value1(operand),operand);//해당 값 분석해서 출력
				fprintf(lst,"%X\n",obj_code);
			}
			else if(type_flag==1){//X'05'가 나오거나 X'150'이 나올 경우를 고려해서 따로 출력해주었다.
				temp=strtok(operand,"'");
				temp=strtok(NULL,"'");
				if(strlen(temp)%2==1)
					fprintf(lst,"0");
				fprintf(lst,"%s\n",temp);
			}
			continue;
		}
	}
	fprintf(lst,"%-10d               END    %s\n",linectr+5,first);//마지막 줄 출력
	fclose(f);
	fclose(lst);
	write_obj(f_name);//obj파일을 쓰는 write_obj함수를 호출한다
}
int format2(char *operand){//opcode가 format 2일 경우에 register 종류에 따라 obj_code에 들어갈 bit값들을 return해주는 함수이다.
	int ans=0,flag=0;
	char *temp;
	if(strchr(operand,',')!=NULL) flag=1;//flag=1이면 register 2개, flag=0이면 register 1개
	temp=strtok(operand,",");
	if(strcmp(temp,"A")==0) ans+=0*16;
	else if(strcmp(temp,"X")==0) ans+=1*16;
	else if(strcmp(temp,"L")==0) ans+=2*16;
	else if(strcmp(temp,"B")==0) ans+=3*16;
	else if(strcmp(temp,"S")==0) ans+=4*16;
	else if(strcmp(temp,"T")==0) ans+=5*16;
	else if(strcmp(temp,"F")==0) ans+=6*16;
	else if(strcmp(temp,"PC")==0) ans+=8*16;
	else if(strcmp(temp,"SW")==0) ans+=9*16;
	if(flag){
		temp=strtok(NULL,"\0");
		temp=Delete_Space(temp);
		if(strcmp(temp,"A")==0) ans+=0;
		else if(strcmp(temp,"X")==0) ans+=1;
		else if(strcmp(temp,"L")==0) ans+=2;
		else if(strcmp(temp,"B")==0) ans+=3;
		else if(strcmp(temp,"S")==0) ans+=4;
		else if(strcmp(temp,"T")==0) ans+=5;
		else if(strcmp(temp,"F")==0) ans+=6;
		else if(strcmp(temp,"PC")==0) ans+=8;
		else if(strcmp(temp,"SW")==0) ans+=9;
	}
	return ans;
}
void write_obj(char *f_name){//obj 파일을 작성해주는 함수이다.lst파일을 input으로 읽어와서 분석 후 obj파일을 작성한다.
	FILE* lst,*obj;
	char f_lst[30],f_obj[30],line[200],obj_code[10][31];
	int i,locctr,indexloc,idx,cnt,flag;
	m_ptr head=(M*)malloc(sizeof(M)),move,new;
	head->pivot=0;//modify 해줘야하는 obj_code들 linkedlist로 저장해준다
	head->next=NULL;
	move=head;
	strcpy(f_lst,f_name);
	strcpy(f_obj,f_name);
	strcat(f_lst,".lst");
	strcat(f_obj,".obj");
	lst=fopen(f_lst,"r");
	obj=fopen(f_obj,"w");
	fprintf(obj,"H%-6s%06X%06X\n",program_name,start_address,program_length);//첫 줄에 들어갈 정보는 이미 다 알고 있으므로 그냥 출력해준다. 이후 다음 줄 index부분까지 출력해준다
	idx=0;//obj_code[10][31]에 31개 제한인 string인 10개씩 돌아가면서 들어간다. 이를 접근하기위한 변수이다
	cnt=0;//byte가 30개가 넘는지 세기위한 cnt
	flag=1;//개행 여부를 체크하는 flag이다. 개행이 된 상태면 1, 개행이 안된 상태면 0이다
	indexloc=start_address;//Test Record에서 해당 줄의 시작 locctr을 저장하는 변수
	fgets(line,input_MAX,lst);//START directive line 스킵(obj code에 영향 없음)
	while((fgets(line,input_MAX,lst))!=NULL){
		if((line[18]=='.'||line[10]==' ')||(line[25]=='B'&&line[26]=='A'))//주석이거나 BASE directive일  경우 그냥 넘어간다
			continue;
		else if('0'>line[47]||line[47]>'F'){//obj_code없을 경우(RESB, RESW의 경우이다) 개행 해줘야 한다.
			sscanf(line,"%*10c%X",&locctr);
			if(program_length+start_address-1==locctr){//프로그램 끝날 경우 개행하여 저장 되있던 obj_code코드들만 출력해주고 종료한다
				fprintf(obj,"T%06X%02X",indexloc,cnt);
				for(i=0;i<idx;i++)
					fprintf(obj,"%s",obj_code[i]);
				fprintf(obj,"\n");
				break;
			}
			if(flag!=1){//개행이 된 상태가 아닌 경우(flag=0) 이전까지 저장 되있던 obj_code들을 출력해주고 개행을 해준다.(개행이 됬고 더이상 obj_code 출력하지 않으므로 flag=1이 된다)
				fprintf(obj,"T%06X%02X",indexloc,cnt);
				for(i=0;i<idx;i++){
					fprintf(obj,"%s",obj_code[i]);
				}
				fprintf(obj,"\n");
				idx=0;
				cnt=0;//개행이 된 상태이므로 출력할 obj_code는 없을 것이다.
				flag=1;
			}
		}
		else{
			sscanf(line,"%*10c%X%*33c%s",&locctr,&(obj_code[idx][0]));//lst파일 형식에 맞게 locctr, obj_code(string)으로 입력받는다
			if(strlen(obj_code[idx])==8&&line[32]!='#'){//extend mode인데 immediate아니면 modify해줘야한다 (주소값인데 addressing mode 사용되지 않음)
				head->pivot++;
				new=(M*)malloc(sizeof(M));
				new->pivot=indexloc+cnt+1;//modify 되야 할 index 값을 저장해 modify node를 링크드리스트에 추가시켜준다
				new->next=NULL;
				move->next=new;
				move=new;
			}
			if((cnt+strlen(obj_code[idx])/2>30)){//개행 해야될 경우이다. 개행을 하고 그 후에 현재 입력 받아져있는 obj_code를 idx=0번으로 땡겨준다(다음 줄에서 제일 처음 출력될 obj_code가 된다)
				fprintf(obj,"T%06X%02X",indexloc,cnt);
				for(i=0;i<idx;i++){
					fprintf(obj,"%s",obj_code[i]);
				}
				fprintf(obj,"\n");
				strcpy(obj_code[0],obj_code[idx]);
				idx=1;
				cnt=strlen(obj_code[0])/2;
				indexloc=locctr;//해당 줄에서 첫번째 obj_code가 되니까 index update
				flag=0;
			}
			else{
				if(flag==1)//개행이 된 상태인데 첫 obj_code가 들어온 경우 index update
					indexloc=locctr;
				cnt+=strlen(obj_code[idx])/2;
				idx++;
				flag=0;
			}
			if(program_length+start_address-1==locctr){//프로그램 끝나면 들어와있던 obj_code코드들 다 출력해준다
				fprintf(obj,"T%06X%02X",indexloc,cnt);
				for(i=0;i<idx;i++)
					fprintf(obj,"%s",obj_code[i]);
				fprintf(obj,"\n");
				break;
			}
		}
	}	
	move=head->next;
	for(i=0;i<head->pivot;i++){//Modification line 출력
		fprintf(obj,"M%06X05\n",move->pivot);
		new=move;
		move=move->next;
		free(new);//출력한 후 바로 free
	}
	free(head);
	fprintf(obj,"E%06X\n",start_address);//END line 출력
	fclose(obj);
	fclose(lst);
}
void symbol(){//sym_table에 들어와있는 symbol들을 모두 출력해주는 함수이다. 
	int i,j,flag=0;
	sym_ptr move;
	for(i=0;i<26;i++){
		move=sym_table[i]->next;
		if(sym_table[i]->address==0)
			flag++;
		for(j=0;j<sym_table[i]->address;j++){
			printf("	%s	%04X\n",move->label,move->address);
			move=move->next;
		}
	}
	if(flag==26)//symbol이 없으면 없다고 출력한다
		printf("There is no symboltable that suceed before\n");
}
int add_symbol(char* label,int locctr){//오류면 1 return, 오류 아니면 0 return
	int hash=(label[0]-'A')%26,idx;//테이블 index는 알파벳순으로 정해지도록 구현하였다
	sym_ptr new,move=tsym_table[hash],move2;
	new=(sym*)malloc(sizeof(sym));
	strcpy(new->label,label);
	new->address=locctr;
	new->next=NULL;
	idx=1;
	if(search_opcode(label,1)!=-1) return 1;//symbol이 이미 예약되있는 directive과 이름이 같은 경우 오류
	else if(strcmp(label,"START")==0) return 1;
	else if(strcmp(label,"BYTE")==0) return 1;
	else if(strcmp(label,"RESB")==0) return 1;
	else if(strcmp(label,"RESW")==0) return 1;
	else if(strcmp(label,"WORD")==0) return 1;
	else if(strcmp(label,"BASE")==0) return 1;
	else if(strcmp(label,"END")==0) return 1;
	while(1){//저장은 tsym_table에 한다. add_symbol은 PASS1단계에서 호출되는 함수이기 때문에, 오류가 발생한다면 이전에 set 됐던 symbol table을 사용할 수 있어야하기 때문이다. tsym_table의 값은 PASS1이 끝난후 copy_symbol함수를 통해 복사된다.
		if(move->next==NULL){
			move->next=new;
			break;
		}
		move2=move->next;
		if(!strcmp(move2->label,new->label)){//같은 symbol이 있을 경우 오류
			return 1;
		}
		if(new->label[idx]<move2->label[idx]){
			move->next=new;
			new->next=move2;
			break;
		}
		else if(new->label[idx]==move2->label[idx]){
			idx++;
		}
		else if(new->label[idx]>move2->label[idx]){
			move=move2;
			move2=move->next;
			idx=1;
		}
	}
	tsym_table[hash]->address++;
	return 0;
}
void copy_symbol(){//PASS1이 끝난 후 입력된 프로그램이 문제가 없다는게 확인 됐으니 sym_table로 tsym_table의 값을 옮겨준다.
	int i;
	sym_ptr move1,move2,new;
	for(i=0;i<26;i++){
		sym_table[i]->address=tsym_table[i]->address;
		move1=sym_table[i];
		move2=tsym_table[i]->next;
		while(move2!=NULL){
			new=(sym*)malloc(sizeof(sym));
			new->address=move2->address;
			strcpy(new->label,move2->label);
			new->next=NULL;
			move1->next=new;
			move1=move1->next;
			move2=move2->next;
		}
	}
}
void free_symbol(int mode){//sym_table을 free하는 함수이다. mode==1이면 sym_table free, mode==2이면 tsym_table free
	sym_ptr free1, temp;
	int i;
	if (mode==1){
		for(i=0;i<26;i++){
			sym_table[i]->address=0;
			free1=sym_table[i]->next;
			while(free1!=NULL){
				temp=free1->next;
				free(free1);
				free1=temp;
			}
			sym_table[i]->next=NULL;
		}
	}
	else if(mode==2){
		for(i=0;i<26;i++){
			tsym_table[i]->address=0;
			free1=tsym_table[i]->next;
			while(free1!=NULL){
				temp=free1->next;
				free(free1);
				free1=temp;
			}
			tsym_table[i]->next=NULL;
		}	
	}
}
int analyze_value1(char* operand){//decimal type이면 0, hexa면 1, char이면 2
	if(strchr(operand,39)==NULL)
		return 0;
	else if(operand[0]=='X')
		return 1;
	else if(operand[0]=='C')
		return 2;
	return 0;
}
int analyze_value2(int type_flag,char* operand){//type_flag에 따라 16진수로 출력했을 때 알맞게 나오도록 계산 후 return 해준다
	char *value,temp[30];
	int i,digit,ans;
	strcpy(temp,operand);
	if(type_flag==0){//decimal
		return change_decimal_to_int(operand);
	}
	else if(type_flag==1){//hexa
		value=strtok(temp,"'");
		value=strtok(NULL,"'");
		return change_string_to_int(value);
	}
	else if(type_flag==2){//string type이다. 한 자리마다 1byte를 차지해야하므로 256씩 곱해주었다.
		ans=0;
		digit=1;
		value=strtok(temp,"'");
		value=strtok(NULL,"'");
		for(i=strlen(value)-1;i>=0;i--){
			ans+=value[i]*digit;
			digit*=256;
		}
		return ans;
	}
	return 0;
}
int analyze_mode(char* operand){//#이면 1 return,@이면 2 return,  (#, @) 아니면 0 return. 그 후 operand 앞에있는 기호를 떼준다
	unsigned int i;
	if(operand[0]=='#'){
		for(i=1;i<=strlen(operand);i++){
			operand[i-1]=operand[i];
		}
		return 1;
	}
	if(operand[0]=='@'){
		for(i=1;i<=strlen(operand);i++){
			operand[i-1]=operand[i];
		}
		return 2;
	}
	return 0;
}
int analyze_opcode(char* opcode){//+이면 1 return, + 아니면 0 return. 그 후 opcode앞에있는 기호를 떼준다
	unsigned int i;
	if(opcode[0]=='+'){
		for(i=1;i<=strlen(opcode);i++){
			opcode[i-1]=opcode[i];
		}
		return 1;
	}
	return 0;
}
int search_symbol(char* symbol){//sym_table에서 symbol을 검색하고 없으면 -1, 있으면 해당 locctr을 return 해준다
	int idx;
	sym_ptr move;
	idx=symbol[0]-'A';
	move=sym_table[idx];
	while(move!=NULL){
		if(!strcmp(move->label,symbol))
			return move->address;
		move=move->next;
	}
	return -1;
}
int search_opcode(char* opcode,int mode){//mode=1이면 format, mode=2이면 opcode값, 없으면 -1 return
	int idx;
	code_ptr move;
	idx=get_hash(opcode);
	move=hash_table[idx];
	while(move!=NULL){
		if(!strcmp(move->code,opcode)){
			if(mode==1)
				return move->format;
			else if(mode==2)
				return move->num;
			break;
		}
		move=move->next;
	}
	return -1;
}
int change_decimal_to_int(char* str){//10진수 string을 정수로 바꾸어주는 함수이다
	int ten=1,move=strlen(str)-1,result=0;
	while(move>=0){
		result+=change_char_to_int(str[move])*ten;
		move--;
		ten*=10;
	}
	return result;
}
void set_system(){//시스템 환경을 구성해주는 함수이다.
	int i;
	progaddr=0;
	csaddr=0;
	head_bp=(bp*)malloc(sizeof(bp));
	head_bp->point=0;
	DUMP[2]=-1;//du 함수가 처음 실행될 경우를 위해 dump[2]=-1로 세팅해준다
	head=(his*)malloc(sizeof(his));
	head->index=0;
	for(i=0;i<20;i++){//hash_table 링크드 리스트 구조의 헤드노드를 세팅한다
		hash_table[i]=(op*)malloc(sizeof(op));
		hash_table[i]->next=NULL;
		hash_table[i]->num=0;
	}
	read_txt();//opcode.txt를 읽는 read_txt함수를 호출해준다
	for(i=0;i<26;i++){//table값 세팅
		sym_table[i]=(sym*)malloc(sizeof(sym));
		sym_table[i]->next=NULL;
		sym_table[i]->address=0;
		tsym_table[i]=(sym*)malloc(sizeof(sym));
		tsym_table[i]->next=NULL;
		tsym_table[i]->address=0;
	}
	for(i=0;i<3;i++){
		esym_table[i]=(ex*)malloc(sizeof(ex));
		esym_table[i]->next=NULL;
		esym_table[i]->address=0;
		esym_table[i]->flag=0;
	}
}
void read_txt(){//opcode.txt를 읽어와서 hash_table 자료구조에 저장해주는 함수이다
	FILE* opcode_list=fopen("opcode.txt","r");
	int temp,index;
	char temp1[10],temp2[10];
	code_ptr move,new;
	while(EOF !=fscanf(opcode_list,"%x %s %s",&temp,temp1,temp2)){
		index=get_hash(temp1);
		if(hash_table[index]->num==0){//각 row로 처음 들어오는 경우(이 때를 위해 set_system함수에서 num==0으로 미리 설정해놓았다)
			hash_table[index]->num=temp;
			strcpy(hash_table[index]->code,temp1);
			hash_table[index]->format=temp2[0]-'0';
		}
		else{//각 row에 들어올 때 처음이 아닌 경우
			move=hash_table[index];
			while(move->next!=NULL)
				move=move->next;
			new=(op*)malloc(sizeof(op));
			new->num=temp;
			strcpy(new->code,temp1);
			new->format=temp2[0]-'0';
			new->next=NULL;
			move->next=new;
		}
	}
}
void dump(char* input){//dump 명령을 수행하는 dump 함수이다 dump 연산이 처음 실행될 경우 구분을 위해 dump[2]=-1로 설정해놓았다
	int temp;
	char *start=NULL,*end=NULL,*check=NULL;
	DUMP[0]=0;
	DUMP[1]=0;//start index 안 들어올 경우를 대비해 dump[1]=0으로 세팅
	strcpy(H_TEMP,input);//history 자료구조에 넣기 위해 H_TEMP에 명령 전체를 복사해놓는다
	start=strtok(input," \t");//dump,du 명령만 따로 자른다(이후의 index와 같은 부분을 구분하기 위함) 
	if(H_TEMP[strlen(H_TEMP)-1]==','){//에러체크(명령 마지막에 ,가 들어갈 경우)
		printf("Input Error, Input h or help to get help\n");
		return ;
	}
	start=strtok(NULL,",");//dump,du 명령 다음으로 나오는 값의 주소를 ,까지 받아놓는다 ,가 없으면 문자열 끝까지 저장된다
	if(start==NULL||over_empty_check(start)==2){//dump 명령이후 문자열에 값이 없거나, 공백만 있을 경우
		check=strtok(NULL,"");//(dump ,)의 경우 에러 체크
		if(check!=NULL){
			printf("Input Error, Input h or help to get help\n");
			return ;
		}
		check_index_memory(start,end);//DUMP[1],DUMP[2]에 start, end 주소 값을 넣어준다
		return ;
	}
	if(over_empty_check(start)&&over_empty_check(start)!=2){//dump 명령이후 문자열이 있을 경우, 예외 처리 되는 경우 구분(over_empty_check 함수로)
		printf("Input Error, Input h or help to get help\n");
		return ;
	}
	start=Delete_Space(start);//쓸 데 없는 공백 제거
	DUMP[0]++;//여기 까지 코드가 진행됐으면 최소 index
	DUMP[1]=change_string_to_int(start);//DUMP[1]에 start index 저장
	if(DUMP[1]==-1||DUMP[1]>0xFFFFF){//잘못된 string인 경우(다른 문자 섞여있음) -1이 return된다, 잘못된 index일 경우 에러체크
		printf("Input Error, Input h or help to get help\n");
		return;
	}
	end=strtok(NULL,"\0");//end index 저장
	if(end==NULL){//end index를 입력하지 않은 경우
		check_index_memory(start,end);//DUMP[0]=1이고, 해당 상태로 check_index_memory를 호출한다
		return ;
	}
	if(over_empty_check(end)){//end가 비었거나, 잘못된 string일 경우
		printf("Input Error, Input h or help to get help\n");
		return ;
	}
	end=Delete_Space(end);//end내에 공백 삭제
	DUMP[0]++;//end에 올바른 index 들어갔으므로 DUMP[0]=2로 바꾸어준다
	temp=change_string_to_int(end);//temp에 index값 저장(index가 잘못된 경우, dump[2]는 이전 index를 저장해야 하기 때문에 temp를 사용한다
	if(temp==-1||temp>0xFFFFF||temp<DUMP[1]){//end index값이 잘못된 경우
		printf("Input Error, Input h or help to get help\n");
		return;
	}
	else
		DUMP[2]=temp;//DUMP[2]에 end index 저장
	check_index_memory(start,end);//DUMP[0]=2이고, 해당 상태로 check_index_memory를 호출한다
}
void check_index_memory(char *start,char *end){
	if(DUMP[0]==0){
		DUMP[1]=DUMP[2]+1;//index 입력없을 경우 최근 dump 명령 끝 다음 인덱스 부터 출력해야한다
		if(DUMP[1]==0xFFFFF+1)//start index가 범위를 벗어날 경우 0으로 초기화한다
			DUMP[1]=0;
		DUMP[2]=DUMP[1]+159;//start부터 160개 출력
	}
	else if(DUMP[0]==1){
		DUMP[2]=DUMP[1]+159;//start부터 160개 출력(index error 이미 수행해주었다)
	}
	if(DUMP[2]>0xFFFFF)
		DUMP[2]=0xFFFFF;
	print_memory();//올바른 index로 memory를 출력한다
	make_his_form(DUMP[0],start,end,NULL);//올바른 history 형태(명령어 start index, (mid index, ), end index로 저장
}
void print_memory(){
	int index,remainder,f,move=DUMP[1];
	while(move<=DUMP[2]){//move가 DUMP[2]가 될 때까지 출력
		index=move/16;//i는 왼쪽 index 부분을 출력할 때 쓰인다
		printf("%04X0 ",index);	
		remainder=move%16;//j는 memory 값들을 출력할 때 start, end index가 16의 배수가 아닌 경우를 위해 쓰인다
		for(f=0;f<remainder;f++)
			printf("   ");
		for(index=move;index<move+16-remainder;index++){
			if(index>DUMP[2])
				printf("   ");
			else
				printf("%02X ",Memory[index]);
		}
		printf("; ");
	/////////////////////////////////////
		for(f=0;f<remainder;f++)
			printf(".");
		for(f=0;f<16-remainder;f++){
			if((Memory[move]>=0x20&&Memory[move]<=0x7E)&&move<=DUMP[2])//오른쪽 아스키코드 부분에서 알맞는 문자 출력
				printf("%c",Memory[move]);
			else
				printf(".");
			move++;
		}
		printf("\n");
	}
}
void edit(char* input){
	char *address,*value;
	int A=0,V=0;
	strcpy(H_TEMP,input);//history 자료구조에 넣기 위해 H_TEMP에 명령 전체를 복사 해놓는다
	address=strtok(input," \t");//e,edit 명령만 따로 자른다(이후의 index와 같은 부분을 구분하기 위함)
	address=strtok(NULL,",");//e,edit 명령 다음으로 나오는 값의 주소를 ,까지 받아놓는다 ,가 없으면 문자열 끝까지 저장된다
	if(address==NULL){//index 입력 안된 경우, 에러체크
		printf("Input Error, Input h or help to get help\n");
		return ;
	}
	if(*(address-1)==','){//끝에 ,만 있는 경우, 에러체크
		printf("Input Error, Input h or help to get help\n");
		return ;
	}
	if(over_empty_check(address)){//start index 잘못 된 경우, 에러체크
		printf("Input Error, Input h or help to get help\n");
		return;
	}
	address=Delete_Space(address);//start index에 있는 공백을 다 지워준다
	A=change_string_to_int(address);//address 문자열 정수로 바꾸어준다
	if(A==-1||A>0xFFFFF){//잘못된 string인 경우, 잘못된 값인 경우 에러체크
		printf("Input Error, Input h or help to get help\n");
		return ;
	}
	value=strtok(NULL,"\0");//value 입력받는다
	if(value==NULL){//end index 입력 안된 경우, 에러체크
		printf("Input Error, Input h or help to get help\n");
		return ;
	}
	if(over_empty_check(value)){//value 잘못 된 경우, 에러체크
		printf("Input Error, Input h or help to get help\n");
		return;
	}
	value=Delete_Space(value);//value에 있는 공백을 다 지워준다
	V=change_string_to_int(value);//value 문자열 정수로 바꾸어준다
	if(V==-1||V>0XFF){//잘못된 string인 경우, 잘못된 값인 경우 에러체크
		printf("Input Error, Input h or help to get help\n");
		return;
	}
	Memory[A]=V;//모든 조건을 통과하면, edit 한다
	make_his_form(2,address,value,NULL);//정제된 history 형태로 명령문을 저장
}
void fill(char* input){
	char *start,*end,*value;
	int S=0,E=0,V=0,i;
	strcpy(H_TEMP,input);//history 자료구조에 넣기 위해 H_TEMP에 명령 전체를 복사 해놓는다
	start=strtok(input," \t");//f,fill 명령만 따로 자른다(이후의 index와 같은 부분을 구분하기 위함)
	start=strtok(NULL,",");//f,fill 명령 다음으로 나오는 값의 주소를 ,까지 받아놓는다 ,가 없으면 문자열 끝까지 저장된다
	if(start==NULL){//index 입력 안된 경우, 에러체크
		printf("Input Error, Input h or help to get help\n");
		return ;
	}
	if(*(start-1)==','){//끝에 ,만 있는 경우, 에러체크
		printf("Input Error, Input h or help to get help\n");
		return ;
	}
	if(over_empty_check(start)){//start index 잘못 된 경우, 에러체크
		printf("Input Error, Input h or help to get help\n");
		return;
	}
	start=Delete_Space(start);//start index에 있는 공백을 다 지워준다
	S=change_string_to_int(start);//start 문자열 정수로 바꾸어준다
	if(S==-1||S>0xFFFFF){//잘못된 string인 경우, 잘못된 주소값인 경우 에러체크
		printf("Input Error, Input h or help to get help\n");
		return ;
	}
	end=strtok(NULL,",");//end 입력받는다
	if(end==NULL){//end index 입력 안 된 경우, 에러체크
		printf("Input Error, Input h or help to get help\n");
		return ;
	}
	if(over_empty_check(end)){//end 잘못 된 경우, 에러체크
		printf("Input Error, Input h or help to get help\n");
		return;
	}
	end=Delete_Space(end);//end에 있는 공백을 다 지워준다
	E=change_string_to_int(end);//end 문자열을 정수로 바꾸어준다
	if(E==-1||E>0xFFFFF){//잘못된 string인 경우, 잘못된 주소값인 경우 에러체크
		printf("Input Error, Input h or help to get help\n");
		return ;
	}
	if(S>E){//start index가 end index보다 큰 경우, 에러체크
		printf("Input Error, Input h or help to get help\n");
		return ;
	}
	value=strtok(NULL,"\0");//value 입력받는다
	if(value==NULL){//value 입력 안 된 경우, 에러체크
		printf("Input Error, Input h or help to get help\n");
		return ;
	}
	if(over_empty_check(value)){//value 잘못 된 경우, 에러체크
		printf("Input Error, Input h or help to get help\n");
		return;
	}
	value=Delete_Space(value);//value 있는 공백을 다 지워준다
	V=change_string_to_int(value);//value 문자열을 정수로 바꾸어준다
	if(V==-1||V>0XFF){
		printf("Input Error, Input h or help to get help\n");
		return ;
	}
	for(i=S;i<=E;i++)//Memory 값 알맞게 fill한다
		Memory[i]=V;
	make_his_form (3,start,end,value);//정제된 history 형태로 명령문을 저장
}
void mnemonic(char* input){//opcode를 읽어서 해당 코드를 출력해주는 함수이다
	int index;
	char*M;
	code_ptr move;
	strcpy(H_TEMP,input);//정제된 form으로 history에 넣기 위해 H_TEMP에 복사해놓는다
	M=strtok(input," \t");
	M=strtok(NULL,"");//M에 해당 opcode 문자열로 저장
	M=Delete_Space(M);
	if(M==NULL){//에러체크
		printf("Input Error, Input h or help to get help\n");
		return ;
	}
	if(over_empty_check(M)){//에러체크
		printf("Input Error, Input h or help to get help\n");
		return ;
	}
	index=get_hash(M);//만들어진 해쉬 테이블에서의 해쉬 값을 찾는다
	move=hash_table[index];
	while(move!=NULL){//move를 증가시켜가며 M과 비교해보고 strcmp로 일치한다면 코드를 출력하고 history에 추가시켜준다
		if(!strcmp(move->code,M)){
			printf("opcode is %02X\n",move->num);
			make_his_form(1,M,NULL,NULL);
			return ;
		}
		move=move->next;
	}
	printf("Input Error, Input h or help to get help\n");//hash table에 없을 경우 에러
}
int get_hash(char* M){//문자열을 입력받아 해쉬 값을 리턴해주는 함수이다.
	int i,len=strlen(M),hash=0;
	for(i=0;i<len;i++){//해쉬 값을 얻는 방식은 문자열의 모든 아스키코드값을 더하고 마지막에 첫번째 글자의 아스키코드를 추가로 더한 후 20의 나머지를 구하는 방식으로 구현하였다
		hash+=M[i];
	}
	hash+=M[0];
	return (hash%20);	
}
void make_his_form(int mode,char* a1,char* a2, char* a3){//du의 mode에 따라(DUMP[0]) mode가 바뀌고, edit이면 mode=2,fill이면 mode=3이 된다.
	unsigned int move=0;
	while((H_TEMP[move]!=' '&&H_TEMP[move]!='\t')&&H_TEMP[move]!=0)
		move++;
	H_TEMP[move]='\0';//dump면 dump, edit이면 edit, 이렇게 명령까지만 저장되도록 한다.
	if(mode==0){//du일 경우
		add_history(H_TEMP);
		return ;
	}
	strcat(H_TEMP," ");
	for(move=0;move<strlen(a1);move++)//모든 index, value값은 대문자로 한다
		if(a1[move]>='a'&&a1[move]<='z')
			a1[move]-=32;
	strcat(H_TEMP,a1);//공백+index 추가
	if(mode==1){//du index 일 경우
		add_history(H_TEMP);
		return ;
	}
	strcat(H_TEMP,", ");
	for(move=0;move<strlen(a2);move++)//모든 index, value값은 대문자로 한다
		if(a2[move]>='a'&&a2[move]<='z')
			a2[move]-=32;
	strcat(H_TEMP,a2);//,공백+index 추가
	if(mode==2){//du start,end 아니면 edit 명령문일 경우
		add_history(H_TEMP);
		return ;
	}
	strcat(H_TEMP,", ");
	for(move=0;move<strlen(a3);move++)//모든 index, value값은 대문자로 한다
		if(a3[move]>='a'&&a3[move]<='z')
			a3[move]-=32;
	strcat(H_TEMP,a3);//,공백+index 추가
	add_history(H_TEMP);//fill 명령문일 경우
}
void opcodelist(){//read_txt 함수에서 만들어졌던 hash table을 불러와서 모든 opcode 정보들을 출력해준다
	int i;
	code_ptr move;
	for(i=0;i<20;i++){
		printf("%d : ",i);
		move=hash_table[i];
		while(move!=NULL){
			printf("[%s, %X]",move->code,move->num);
			move=move->next;
			if(move==NULL)
				break;
			else
				printf(" -> ");
		}
		printf("\n");
	}
}
void help(){//help 내용을 출력해준다
	printf("h[elp]\nd[ir]\nq[uit]\nhi[story]\ndu[mp] [start, end]\n");
	printf("e[dit] address, value\nf[ill] start, end, value\n");
	printf("reset\nopcode mnemonic\nopcodelist\n");
	printf("assemble filename\ntype filename\nsymbol\n");
	printf("progaddr [address], loader[object filename1][object filename2][...]\n");
	printf("bp [address], run\n");
}
void dir(){//directory 안의 내용들을 출력해준다
	DIR* dir_ptr=NULL;
	struct dirent *file=NULL;
	struct stat buf;
	if((dir_ptr=opendir("."))==NULL){
		printf("directory 정보를 얻을 수 없습니다.\n");
		return ;
	}
	while((file=readdir(dir_ptr))!=NULL){
		lstat(file->d_name,&buf);

		if(S_ISDIR(buf.st_mode)){//directory면 /을 붙여서 출력해준다
			printf("%s/\n",file->d_name);
		}
		else if((buf.st_mode>0)&&(S_IEXEC&buf.st_mode)){//execution 파일이면 *을 붙여서 출력해준다
			printf("%s*\n",file->d_name);
		}
		else//일반 파일이면 그냥 출력한다
			printf("%s\n",file->d_name);
	}
	closedir(dir_ptr);
	return ;
}
void reset(){//모든 Memory값을 0으로 reset해준다 memset함수를 사용하였다
	memset(Memory,0,16*65536*sizeof(Memory[0]));
}
void add_history(char* input){//input값 입력받아 history 자료구조에 추가한다
	his_ptr new,move;
	new=(his*)malloc(sizeof(his));
	strcpy(new->D,input);
	new->index=++(head->index);
	new->next=NULL;
	move=head;
	while(move->next!=NULL){//끝까지 move
		move=move->next;
	}
	move->next=new;
}
void history(){//history 자료구조에(linked list)저장 되있는 명령문들 순서대로 출력
	his_ptr move;
	move=head;
	while(move->next!=NULL){
		printf("%d %s\n",move->next->index,move->next->D);
		move=move->next;
	}
}
void free_data(){//history 자료구조, hash_table 자료구조를 free 해준다
	his_ptr free1,temp1;
	code_ptr free2,temp2;
	ex_ptr free3,temp3;
	int i=0;
	free1=head;
	while(free1!=NULL){
		temp1=free1->next;
		free(free1);
		free1=temp1;
	}
	for(i=0;i<20;i++){
		free2=hash_table[i];
		while(free2!=NULL){
			temp2=free2->next;
			free(free2);
			free2=temp2;
		}
	}
	free_symbol(1);//만약 한 프로그램 내에 assemble이 두번 실행 되는 거라면 symbol table이 free돼야 한다
	for(i=0;i<3;i++){
		free3=esym_table[i];
		while(free3!=NULL){
			temp3=free3->next;
			free(free3);
			free3=temp3;
		}
	}
}
int over_empty_check(char *string){//단어+공백+단어의 형태일 경우, 입력된 string이 모두 공백일 경우를 찾아주는 함수이다
	int flag=0;
	unsigned int move=0;
	while(move<strlen(string)){
		if(string[move]!=' '&&string[move]!='\t'){
			flag=1;
			break;
		}
		move++;
	}
	if(!flag)//모두 공백일 경우 2를 return한다, 에러체크
		return 2;
	flag=0;
	while(move<strlen(string)){
		if(flag==0&&(string[move]!=' '&&string[move]!='\t')){
			flag=1;
		}
		if(flag==1&&(string[move]==' '||string[move]=='\t')){
			flag=2;
		}
		if(flag==2&&(string[move]!=' '&&string[move]!='\t')){
			return 1;//단어+공백+단어의 형태일 경우 1을 return한다, 에러체크
		}
		move++;
	}
	return 0;//문제 없으면 0을 return한다
}
int change_char_to_int(char c){//문자의 ascii값에 알맞게 정수로 바꿔서 return 해주는 함수이다
	int ans;
	ans=c;
	if(c>=48&&c<=57)
		return ans-48;
	else if(c>=65&&c<=70)
		return ans-55;
	else if(c>=97&&c<=122)
		return ans-87;
	else
		return 0;
}
int change_string_to_int(char* str){//한글자씩 읽어가며 이상한 문자면 -1을 return하고 아니면 정수로 바꾸어서 자릿수에 해당하는 16진수 값을 곱해 더한 후, 최종 값을 return 해준다
	int sixteen=1,move=strlen(str)-1,result=0;
	while(move>=0){
		if(str[move]<'0'||(str[move]>'9'&&str[move]<'A')||(str[move]>'F'&&str[move]<'a')||str[move]>'f'){
			return -1;
		}
		if(str[move]==' '||str[move]=='\t'){
			move--;
			continue;
		}
		result+=change_char_to_int(str[move])*sixteen;
		move--;
		sixteen*=16;
	}
	return result;
}
char* Delete_Space(char* string){//해당 string의 모든 공백(space, tab)을 없애준다
	if(string==NULL)
		return 0;
	char *str=(char*)malloc(sizeof(string));
	int k=0;
	unsigned int i;
	for( i=0;i<strlen(string);i++)
		if(string[i]!=' '&&string[i]!='\t'){
			str[k]=string[i];
			k++;
		}
	str[k]='\0';
	return str;
}
void remove_blank(char* input){//명령어 앞에 공백들이 들어갈 경우를 위해 이를 제거해주는 함수이다
	int move=0,index=0;
	char temp[100];
	while(1){
		if(input[move]==' '||input[move]=='\t')
			move++;
		else 
			break;
	}
	while(1){
		temp[index]=input[move];
		if(input[move]=='\0')
			break;
		move++;
		index++;
	}
	strcpy(input,temp);
}
